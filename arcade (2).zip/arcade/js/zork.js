document.querySelector('.zork').addEventListener('click', function(){
  // código para obter informações do jogo Zork e exibi-las na página
});

document.querySelector('.nome-jogo').innerHTML = $row['nome'];


<script>
function showGameInfo(game) {
    window.location.href = "gameinfo.php" + game;
}



</script>